# Waveform reconstruction in perturbation-based Audio XAI

Balanced Beamer presentation combining the literature novelty audit with the theoretical mechanism and the current experimental evidence.

## Files
- `main.tex`: current balanced presentation.
- `references.bib`: BibLaTeX bibliography.
- `main.pdf`: compiled presentation.
- `main_hybrid_v1_backup.tex`: previous hybrid version.
- `main_audit_only.tex`: literature-focused earlier version.
- `main_full_structural_backup.tex`: more extensive structural version.

## Compile on Overleaf
Use pdfLaTeX + Biber. Overleaf should run Biber automatically because `biblatex` is loaded with `backend=biber`.
